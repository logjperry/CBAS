from setuptools import find_packages, setup

setup(
    name='cbas_headless',
    packages=find_packages(include=['cbas_headless']),
    version='0.1.0',
    description='The Circadian Behavioral Analysis Suite',
    author='Logan Pery',
    install_requires=[],
)