import cv2
import tkinter as tk
from PIL import Image, ImageTk
import threading
import os
import time
import ctypes
import yaml
import os
import math
import sys
from sys import exit
import subprocess
import shutil
import pandas as pd
from tkinter import ttk
import numpy as np
import random

import ttkbootstrap as ttk

from sklearn.metrics import f1_score as f1
from sklearn.metrics import confusion_matrix


class Scoreboard_HL:
    def __init__(self, parent, behaviors, colors, goal):
        self.parent = parent
        self.behaviors = behaviors
        self.colors = colors
        self.goal = goal
        self.create_widgets()

    def create_widgets(self):
        # Create headers
        tk.Label(self.parent, text="Behavior", font=('Arial',9,'bold','underline')).grid(row=0, column=0)
        tk.Label(self.parent, text="Index", font=('Arial',9,'bold','underline')).grid(row=0, column=1)
        tk.Label(self.parent, text="Instances", font=('Arial',9,'bold','underline')).grid(row=0, column=2)

        # Store references to the count and score variables
        self.count_vars = {}
        self.inst_vars = {}

        # Create rows for each name
        for i, name in enumerate(self.behaviors, start=1):
            tk.Label(self.parent, text=name).grid(row=i, column=0)

            # index
            tk.Label(self.parent, text=str(i), bg=self.colors[i-1]).grid(row=i, column=1, pady=3)

            inst_var = tk.StringVar(value="<"+str(self.goal))  # Initial instances
            self.inst_vars[name] = inst_var
            tk.Label(self.parent, textvariable=inst_var).grid(row=i, column=2)



    def update(self, true):

        dones = []

        for b in self.behaviors:
            count = 0
            for inst in true:
                if inst == b:
                    count += 1
            if count<self.goal:
                self.inst_vars[b].set("~"+str(int(count/10)*10)+"/"+str(self.goal))
            else:
                self.inst_vars[b].set('DONE!')
                dones.append(b)

        return dones

class Metricboard_HL:
    def __init__(self, parent, behaviors):
        self.parent = parent
        self.behaviors = behaviors

        self.true = []
        self.pred = []

        self.create_widgets()

    def create_widgets(self):
        # Create headers
        tk.Label(self.parent, text="Behavior", font=('Arial',9,'bold','underline')).grid(row=0, column=0)
        tk.Label(self.parent, text="Precision", font=('Arial',9,'bold','underline')).grid(row=0, column=2)
        tk.Label(self.parent, text="Recall", font=('Arial',9,'bold','underline')).grid(row=0, column=3)
        tk.Label(self.parent, text="F1-score", font=('Arial',9,'bold','underline')).grid(row=0, column=4)
        tk.Label(self.parent, text="Balanced Accuracy", font=('Arial',9,'bold','underline')).grid(row=0, column=5)
        tk.Label(self.parent, text="Matthew's Cor. Coef.", font=('Arial',9,'bold','underline')).grid(row=0, column=6)

        self.precision = {}
        self.recall = {}
        self.f1_score = {}
        self.balanced_acc = {}
        self.matthews_coef = {}

        # Create rows for each name
        for i, name in enumerate(self.behaviors, start=1):
            tk.Label(self.parent, text=name).grid(row=i, column=0)


            precision_var = tk.StringVar(value="?")  # Initial precision
            self.precision[name] = precision_var
            tk.Label(self.parent, textvariable=precision_var).grid(row=i, column=2)

            recall_var = tk.StringVar(value="?")  # Initial recall
            self.recall[name] = recall_var
            tk.Label(self.parent, textvariable=recall_var).grid(row=i, column=3)

            f1_score_var = tk.StringVar(value="?")  # Initial f1 score
            self.f1_score[name] = f1_score_var
            tk.Label(self.parent, textvariable=f1_score_var).grid(row=i, column=4)

            balanced_acc_var = tk.StringVar(value="?")  # Initial balanced acc
            self.balanced_acc[name] = balanced_acc_var
            tk.Label(self.parent, textvariable=balanced_acc_var).grid(row=i, column=5)

            matthews_coef_var = tk.StringVar(value="?")  # Initial matthews coef
            self.matthews_coef[name] = matthews_coef_var
            tk.Label(self.parent, textvariable=matthews_coef_var).grid(row=i, column=6)


    # this is where the magic happens
    def update(self, true, pred):


        metrics = {b:[] for b in self.behaviors}
            
        for b in self.behaviors:

            b_true = [l==b for l in true]
            b_pred = [l==b for l in pred]

            tp = 0
            tn = 0
            fn = 0
            fp = 0

            for i,t in enumerate(b_true):
                if b_pred[i]==t:
                    if t==True:
                        tp+=1
                    else:
                        tn+=1
                if b_pred[i]!=t:
                    if b_pred[i]==True:
                        fp+=1
                    else:
                        fn+=1


            if tp+fp!=0: 
                precision = tp/(tp+fp)
                precision = int(precision*1000)/1000
            else:
                precision = 1

            if tp+fn!=0:
                recall = tp/(tp+fn)
                recall = int(recall*1000)/1000
            else:
                recall = 1

            if precision+recall!=0:
                f1_score = 2*precision*recall/(precision+recall)
                f1_score = int(f1_score*1000)/1000
            else:
                f1_score = 1

            if tn+fp!=0:
                specificity = tn/(tn+fp)
                specificity = int(specificity*1000)/1000
            else:
                specificity = 1

            balanced_acc = (recall+specificity)/2
            balanced_acc = int(balanced_acc*1000)/1000

            if np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))!=0:
                matthews_coef = (tn*tp - fn*fp)/(np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)))
                nmatthews_coef = (matthews_coef+1)/2
                nmatthews_coef = int(nmatthews_coef*1000)/1000
            else:
                nmatthews_coef = 1

            metrics[b].append({
                'precision':precision,
                'recall':recall,
                'f1_score':f1_score,
                'balanced_acc':balanced_acc,
                'matthews_coef':nmatthews_coef
            })


        for b in self.behaviors:

            precisions = [metric['precision'] for metric in metrics[b]]
            recalls = [metric['recall'] for metric in metrics[b]]
            f1_scores = [metric['f1_score'] for metric in metrics[b]]
            balanced_accs = [metric['balanced_acc'] for metric in metrics[b]]
            matthews_coefs = [metric['matthews_coef'] for metric in metrics[b]]

            precision = int(np.mean(precisions)*1000)/1000
            recall = int(np.mean(recalls)*1000)/1000
            f1_score = int(np.mean(f1_scores)*1000)/1000
            balanced_acc = int(np.mean(balanced_accs)*1000)/1000
            matthews_coef = int(np.mean(matthews_coefs)*1000)/1000

                    
            self.precision[b].set(value=str(precision))
            self.recall[b].set(value=str(recall))
            self.f1_score[b].set(value=str(f1_score))
            self.balanced_acc[b].set(value=str(balanced_acc))
            self.matthews_coef[b].set(value=str(matthews_coef))

class HumanLabel:
    def __init__(self, window, window_title, instance_paths, testing_config, behaviors_ordered=None, seq_len=7, grade=True, replays=3, goal=2, trues=None, preds=None):
        self.window = window
        self.window.title(window_title)
        self.instances = []
        self.testing_config = testing_config

        instances = []
        test_instances = []

        self.behaviors = []
        if behaviors_ordered is not None:
            self.behaviors = behaviors_ordered


        self.cur_inst_label = None 
        self.trues = []
        self.preds = []


        if trues is not None:
            self.trues.extend(trues)
        if preds is not None:
            self.preds.extend(preds)

        self.seq_len = seq_len
        self.goal = goal

        self.frame_ind = 0
        self.replays = replays

        for instance_path in instance_paths:
            #print(instance_path)
            with open(instance_path) as file:
                training_set = yaml.safe_load(file)

                behaviors = training_set['behaviors']
                for b in behaviors:
                    if b not in self.behaviors:
                        if behaviors_ordered is None:
                            self.behaviors.append(b)
                    for inst in training_set['instances'][b]:
                            instances.append(inst)


        self.instances = instances
        self.test_instances = test_instances

        self.upper = tk.Frame(self.window)
        

        self.color_list = ['coral','goldenrod1','royalblue','red1','deeppink1','lightslateblue','gray23','limegreen','cornsilk']


        # Load video and predictions
        self.cap = cv2.VideoCapture(self.instances[0]['video'])
        

        self.frame_num = 0

        # Create a canvas that can fit the above video source size
        self.canvas = tk.Canvas(self.upper, width=self.cap.get(cv2.CAP_PROP_FRAME_WIDTH), height=self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.canvas.grid(column=0, row=0)

        self.board_frame = tk.Frame(self.upper)
        self.scoreboard = Scoreboard_HL(self.board_frame, self.behaviors, self.color_list, self.goal)
        self.scoreboard.update(self.trues)
        self.board_frame.grid(column=1, row=0)


        self.upper.pack(anchor=tk.CENTER, pady=5, padx=5)

        
        self.window.bind('r', lambda i: self.replay())

        for i in range(1,len(self.behaviors)+1):
            self.window.bind(str(i), lambda x, i=i: self.guess(i - 1))


        self.metricboard_frame = tk.Frame(self.window)
        self.metricboard = None

        if grade==True:
            self.metricboard = Metricboard_HL(self.metricboard_frame, self.behaviors)
            #self.metricboard.update(self.trues, self.preds)

        self.metricboard_frame.pack(anchor=tk.CENTER, pady=5, padx=5)

        self.frames = []


        # Update & delay variables
        self.delay = 50   # ms

        self.next()
        self.update()

        self.window.mainloop()
    
    def update(self):

        self.window.after(self.delay, self.update)
    
    def replay(self):
        self.frame_ind = 0
        self.play_video()
    
    def guess(self, i):

        pred = self.behaviors[i]
        self.trues.append(self.cur_inst_label)
        self.preds.append(pred)

        dones = self.scoreboard.update(self.trues)

        if set(dones)==set(self.behaviors):
            self.metricboard.update(self.trues, self.preds)

        self.next()

    def play_video(self):
        # Read the next frame from the video. If reached the end of the video, release the video capture object
        ret, frame = self.frames[self.frame_ind%len(self.frames)]
        if self.frame_ind>(self.seq_len*2+1)*self.replays:
            return
        if ret:
            self.canvas.delete("all")
            self.photo = ImageTk.PhotoImage(image=Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)))
            self.canvas.create_image(0, 0, image=self.photo, anchor=tk.NW)

            self.frame_ind+=1
            self.window.after(self.delay, self.play_video)
           

    def next(self):

        # clear the last frames 
        self.frames = []
        self.frame_ind = 0


        # randomly select an instance
        iidx = random.randint(0, len(self.instances)-1)
        inst = self.instances[iidx]

        label = inst['label']
        video = inst['video']
        start = inst['start']
        end = inst['end']
        self.cur_inst_label = label

        self.cap = cv2.VideoCapture(video)

        # Check if the video file was opened successfully
        if not self.cap.isOpened():
            print("Error: Could not open video file.")
            exit()

        total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))

        # randomly select a position in the range of the instance
        central_frame = random.randint(start, end-1)
        start_frame = central_frame - self.seq_len 
        num_frames = self.seq_len*2+1

        if start_frame<1:
            num_frames = num_frames+(1-start_frame)
            start_frame = 1
        
        if start_frame+num_frames > total_frames:
            num_frames += total_frames-1-(start_frame+num_frames)

        # extract those frames from the video

        # Set the frame position
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame - 1)  # Subtract 1 because frame numbering starts from 0

        for i in range(num_frames):
            # Read the frame
            ret, frame = self.cap.read()

            # Check if the frame was read successfully
            if ret:
                self.frames.append((ret, frame))
            else:
                print(f"Error: Unable to extract frame {i+start_frame}")

        # Release the video capture object
        self.cap.release()


        self.play_video()

   
# This function is just expecting a directory with subdirectories containing mp4 videos and labels in the DEG form
def human_label(instance_paths, behaviors=[], grader="Anonymous"):


    hl_trues = os.path.join(hl_dir,grader+"_true.npy")
    hl_preds = os.path.join(hl_dir,grader+"_pred.npy")

    trues=None 
    preds=None

    if os.path.exists(hl_trues):
        with open(hl_trues, 'rb') as f:
            trues = np.load(f)
    if os.path.exists(hl_preds):
        with open(hl_preds, 'rb') as f:
            preds = np.load(f)

    root = tk.Tk()
    hl = HumanLabel(root, 'Human Labeling', instance_paths, testing_config=None, behaviors_ordered=behaviors, goal=1000, trues=trues, preds=preds)

    with open(hl_trues, 'wb') as f:
        np.save(f, np.array(hl.trues))
    with open(hl_preds, 'wb') as f:
        np.save(f, np.array(hl.preds))