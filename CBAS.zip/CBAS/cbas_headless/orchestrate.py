import os
import subprocess
from multiprocessing import Process
import yaml
from sys import exit
import psutil
from datetime import datetime
import time
import signal
import glob
import shutil
import json


def storage_orchestrator(recordingConfig):

    # figure out which cameras to watch
    with open(recordingConfig, 'r') as file:
        rconfig = yaml.safe_load(file)

    cameras = rconfig['cameras']

    cams_to_watch = cameras

    # get the recording folder, for the basic orchestrator, store videos in a general videos folder
    recordingFolder = os.path.join(os.path.split(recordingConfig)[0], 'videos')

    # check to see if it exists already... it shouldn't
    if not os.path.isdir(recordingFolder):
        os.mkdir(recordingFolder)
    
    # make the subfolders for each camera
    for camera in cams_to_watch:
        foldername = os.path.join(recordingFolder, camera['name'])
        if not os.path.isdir(foldername):
            os.mkdir(foldername)

    store_last = []

    # loop indefinitely, check for videos that have finished recording. push done videos to destination folder
    while True:
        
        for camera in cams_to_watch:


            # grab the videos that have been recorded from the core/videos/camera location
            video_dir = camera['video_dir']

            camera_name = camera['name']

            
            # check the camera config to see if finished
            with open(recordingConfig, 'r') as file:
                rconfig = yaml.safe_load(file)

            try:
                if rconfig['cameras_time'][camera_name]['end_time'] is not None:
                    if camera_name not in store_last:
                        store_last.append(camera_name)
            except:
                print('Error loading camera time dictionary.')

            real_videos = []

            files = glob.glob(os.path.join(video_dir, '*'))
            for file in files:
                if os.path.isfile(file):
                    real_videos.append(file)
            
            if len(real_videos)==0:
                continue

            real_videos.sort()

            if camera_name not in store_last:
                # Don't include the last one
                real_videos = real_videos[:-1]


            finished_videos = []

            # find the finished video names
            subfoldername = os.path.join(recordingFolder, camera['name'])
            for subdir, dirs, files in os.walk(subfoldername):
                for file in files:
                    finished_videos.append(os.path.join(video_dir,file))
            
            # discard videos that have already finished from this list
            real_videos = [vid for vid in real_videos if vid not in finished_videos]


            for video in real_videos:
                video_name = os.path.split(video)[1]
                dest = os.path.join(subfoldername,video_name)

                local_time = time.localtime(os.path.getctime(video))
                original_ctime = time.strftime("%H:%M:%S", local_time)

                shutil.copy2(video, dest)

                if os.path.exists(dest):
                    
                    try:
                        os.remove(video)
                    except:
                        print('Error removing file.')

                    # update the camera config
                    with open(recordingConfig, 'r') as file:
                        rconfig = yaml.safe_load(file)
                    
                
                    rconfig['cameras_files'][camera_name].append({video_name:original_ctime})

                    with open(recordingConfig, 'w+') as file:
                        yaml.dump(rconfig, file, allow_unicode=True)
        
        time.sleep(1)


def inference_orchestrator(recordingConfig, modelConfigs):

    loaded_models = {}


    # figure out which cameras to watch
    with open(recordingConfig, 'r') as file:
        rconfig = yaml.safe_load(file)

    models = rconfig['cameras_per_model'].keys()
    

    # Load the relevant models
    for m in models:
        model = None
        for m1 in modelConfigs:
            if m1['name']==m:
                model = m1
        if model==None:
            continue 
        else:
            menv = model['env']
            mtype = model['type']
            mpath = model['path']


            if mtype == 'deepethogram':
                
                env_command = f"conda activate {menv}"

                # Run the command
                try:
                    subprocess.run(env_command, shell=True, check=True)
                    print('Successfully activated the environment!')
                except:
                    raise Exception('Error activating the environment.')

                def get_conda_env_path(env_name):
                    # Run 'conda info --envs' and capture output
                    result = subprocess.run(['conda', 'info', '--envs'], capture_output=True, text=True)
                    if result.returncode != 0:
                        raise Exception("Failed to get Conda environments")

                    # Parse the output to find the desired environment
                    envs = result.stdout.splitlines()
                    env_path = None
                    for env in envs:
                        if env_name in env:
                            env_path = env.split()[-1]  # Assumes the path is the last element
                            break

                    if not env_path:
                        raise Exception(f"Environment '{env_name}' not found")

                    return env_path

                env_name = menv
                env_base_path = get_conda_env_path(env_name)

                # Construct the path to the Python executable
                env_python_path = os.path.join(env_base_path, "python.exe")

                
                # Try finding the deepethogram project
                location = os.path.dirname(os.path.abspath(__file__))

                
                storageFolder = os.path.join(os.path.split(recordingConfig)[0], 'videos')

                pipe = os.path.join(storageFolder, m+'.yaml')


                try:
                    process = subprocess.Popen([env_python_path, os.path.join(location, 'deg.py'), mpath, m, pipe])
                    loaded_models[m] = process
                except subprocess.CalledProcessError as e:
                    # Re-raise the exception if needed, or handle it accordingly
                    raise Exception("Model not loading properly. Make sure this is a deepethogram model and that the correct models are set in the /project_config.yaml file of the project under 'weights:'")


            elif mtype == 'deeplabcut':
                

                env_command = f"conda activate {menv}"

                # Run the command
                try:
                    subprocess.run(env_command, shell=True, check=True)
                    print('Successfully activated the environment!')
                except:
                    raise Exception('Error activating the environment.')

                def get_conda_env_path(env_name):
                    # Run 'conda info --envs' and capture output
                    result = subprocess.run(['conda', 'info', '--envs'], capture_output=True, text=True)
                    if result.returncode != 0:
                        raise Exception("Failed to get Conda environments")

                    # Parse the output to find the desired environment
                    envs = result.stdout.splitlines()
                    env_path = None
                    for env in envs:
                        if env_name in env:
                            env_path = env.split()[-1]  # Assumes the path is the last element
                            break

                    if not env_path:
                        raise Exception(f"Environment '{env_name}' not found")

                    return env_path

                env_name = menv
                env_base_path = get_conda_env_path(env_name)

                # Construct the path to the Python executable
                env_python_path = os.path.join(env_base_path, "python.exe")

                
                # Try finding the deepethogram project
                location = os.path.dirname(os.path.abspath(__file__))

                
                storageFolder = os.path.join(os.path.split(recordingConfig)[0], 'videos')
                modelFolder = os.path.join(os.path.split(recordingConfig)[0], m)

                pipe = os.path.join(storageFolder, m+'.yaml')


                try:
                    process = subprocess.Popen([env_python_path, os.path.join(location, 'dlc.py'), mpath, m, pipe, modelFolder])
                    loaded_models[m] = process
                except subprocess.CalledProcessError as e:
                    # Re-raise the exception if needed, or handle it accordingly
                    raise Exception("Model not loading properly. Make sure this is a deeplabcut model and that you provided the path to the config file.")


    # loop indefinitely, check for videos that have finished recording. push done videos to destination folder

    pipe_set = []

    global_lock = os.path.join(os.path.split(recordingConfig)[0], 'videos','lock.yaml')
    lconfig = {'lock':None, 'dead':[]}
    with open(global_lock, 'w') as file:
        yaml.dump(lconfig, file, allow_unicode=True)



    while True:

        absolute_finish = True
        wu = False

        for m in models:

            # figure out which cameras to watch
            with open(recordingConfig, 'r') as file:
                rconfig = yaml.safe_load(file)


            cameras = rconfig['cameras']
            
            cams_per_model = rconfig['cameras_per_model'][m]
            cams_to_watch = [cam for cam in cameras if cam['name'] in cams_per_model]

            # get the storage folder
            storageFolder = os.path.join(os.path.split(recordingConfig)[0], 'videos')

            pipe = os.path.join(storageFolder, m+'.yaml')

            modelFolder = os.path.join(os.path.split(recordingConfig)[0], m)

            # check to see if it exists already... 
            if not os.path.isdir(modelFolder):
                os.mkdir(modelFolder)
            
            ready = []
            finished = []

            wrapup = False

            if os.path.exists(pipe):
                with open(pipe, 'r') as file:
                    iconfig = yaml.safe_load(file)
                    finished = iconfig['finished']
                    wrapup = iconfig['wrapup']
            else:
                # initialize the pipe
                iconfig = {'ready':ready,'finished':finished,'wrapup':False,'lock':global_lock, 'avg_times':[], 'times':[], 'iter':0}
                with open(pipe, 'w') as file:
                    yaml.dump(iconfig, file, allow_unicode=True)
            

            with open(global_lock, 'r') as file:
                lconfig = yaml.safe_load(file)
                lock = lconfig['lock']
            

            with open(global_lock, 'r') as file:
                lconfig = yaml.safe_load(file)
                lock = lconfig['lock']
            dead = lconfig['dead']

            if m in dead:
                done = True

                for m1 in models:
                    if m1 not in dead:
                        done = False

                if done:
                    break 
                else:
                    continue

            if lock != None:
                done = False
                while not done:
                    time.sleep(5)

                    locked = False
                    with open(global_lock, 'r') as file:
                        lconfig = yaml.safe_load(file)
                        lock = lconfig['lock']

                    if lock==None:
                        done = True
            

            with open(pipe, 'r') as file:
                iconfig = yaml.safe_load(file)
                finished = iconfig['finished']
                wrapup = iconfig['wrapup']
            
            
            for camera in cams_to_watch:

                camera_name = camera['name']

                video_dir = os.path.join(storageFolder, camera_name)

                real_videos = []

                files = glob.glob(os.path.join(video_dir, '*'))
                for file in files:
                    if os.path.isfile(file):
                        real_videos.append(file)
                
                
                if len(real_videos)==0:
                    continue

                real_videos.sort()


                finished_videos = []
                for video in finished:
                    # check to see if the files have been moved

                    source_folder = video
                    video_name = os.path.split(video)[1]
                    dest_folder = os.path.join(modelFolder, video_name)

                    if os.path.exists(dest_folder):
                        finished_videos.append(video_name+'.mp4')
                    else:
                        os.mkdir(dest_folder)
                        done_files = glob.glob(os.path.join(source_folder, '*'))
                        move = []
                        for f in done_files:
                            if os.path.isfile(f) and os.path.splitext(f)[1]!='.mp4':
                                move.append(f)

                        for f in move:

                            dest = os.path.join(dest_folder, os.path.split(f)[1])
                            
                            shutil.copy2(f, dest)

                            if os.path.exists(dest):
                                try:
                                    os.remove(f)
                                except:
                                    print('Error removing file.')

                        if os.path.exists(source_folder):
                            
                            try:
                                shutil.rmtree(source_folder)
                            except:
                                print('Error removing folder.')

                        finished_videos.append(video_name+'.mp4')
                
                
                # discard videos that have already finished from this list
                real_videos = [vid for vid in real_videos if os.path.split(vid)[1] not in finished_videos]


                for rv in real_videos:
                    ready.append(rv)


                

            iconfig = {'ready':ready,'finished':finished,'wrapup':wrapup,'lock':global_lock, 'avg_times':iconfig['avg_times'], 'times':iconfig['times'], 'iter':iconfig['iter']}

            if len(ready)>0:
                absolute_finish = False

                with open(pipe, 'w') as file:
                    yaml.dump(iconfig, file, allow_unicode=True)

                lconfig = {'lock':m, 'dead':lconfig['dead']}
                with open(global_lock, 'w') as file:
                    yaml.dump(lconfig, file, allow_unicode=True)

            if wrapup:
                wu = True
                

            time.sleep(2)

        if absolute_finish and wu:
            break
            


